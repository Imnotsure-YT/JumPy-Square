# def isCollide(col, x, y):
#     n = len(col)
#     for i in range(n):
#         for j in range(4):
#             # col[i][j] = one point
#             # col[i][j][0] is the x coord
#             # col[i][j][1] is the y coord
            
